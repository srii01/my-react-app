// src/TodoList.jsx
import React from 'react';

function TodoList() {
  return (
    <div>
      <h2>Todo List</h2>
      {/* Todo List items here */}
    </div>
  );
}

export default TodoList;
